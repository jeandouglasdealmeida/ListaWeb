var nome = 'Jean Douglas';
var idade = '28';
console.log(typeof nome);
console.log(typeof idade);
document.write(nome,"<br>");
document.write(idade," Anos de Idade <br>");

if (idade >= 18) {
	document.write('Maior de Idade')
}
else{
	document.write('De Menor')
}


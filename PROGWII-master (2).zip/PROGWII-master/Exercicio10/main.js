const tag = document.querySelector('input[name="temperatura"]')
const resultados = document.querySelector('div.resultados')

tag.addEventListener('blur', function(evento) {
    // Continue a tarefa aqui...
    
})
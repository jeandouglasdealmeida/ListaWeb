function clicar() {
	var num1 = document.querySelector(".num1").value;
	var num2 = document.querySelector(".num2").value;

	var somar = parseInt(num1) + parseInt(num2);
	document.querySelector(".soma").innerHTML = (("valor da soma \n") + somar);

	var subtracao = parseInt(num1) - parseInt(num2);
	document.querySelector(".sub").innerHTML = (("valor da subtracao \n") + subtracao);

	var multiplicacao = parseInt(num1) * parseInt(num2);
	document.querySelector(".mult").innerHTML = (("valor da multiplicacao \n") + multiplicacao);

	var divisao = parseInt(num1) / parseInt(num2);
	document.querySelector(".div").innerHTML = (("valor da Divisao \n") + divisao);

	var resto = parseInt(num1) % parseInt(num2);
	document.querySelector(".resto").innerHTML = (("Resto da Divisao \n") + resto);

}
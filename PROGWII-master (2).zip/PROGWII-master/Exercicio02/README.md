##### ORIENTAÇÔES
> Siga as orientações abaixo para resolver a tarefa

###### `index.html`
 - Faça a importação do arquivo styles.css na tag `<head>` e do arquivo main.js na tag `<body>`.
 - Crie uma tag `<h1>` com o texto `Tabuada`

###### `styles.css`
 - Defina uma cor para o texto para da tag `h1`
 - Defina uma cor para o fundo na tag `body`
 
###### `main.js`
1. Crie uma variável com um valor inteiro entre 0 e 10.
2. Imprima a tabuada do número no console do navegador web, utilizando `console.log()`
3. Agora, imprima novamente, mas utlizando algum tipo de loop *(while, for, ...)*
var inteiro = '10';

	for (var i = 0; i <= 10; i++) {
		console.log ([i]*inteiro);
		document.write("<br>"," 10", " x ", i," = " ,[i]*inteiro);
	}
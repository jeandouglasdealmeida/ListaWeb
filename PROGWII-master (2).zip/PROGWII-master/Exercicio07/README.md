##### ORIENTAÇÔES
> Siga as orientações abaixo para resolver a tarefa

###### `index.html`
 - Faça a importação do arquivo styles.css na tag `<head>` e do arquivo main.js na tag `<body>`.
 - Crie uma tag `<h1>` com o texto `Formatar Data`

###### `styles.css`
 - Defina alguns estilos para a página
 
###### `main.js`

1. Faça um script que receba uma data no formato "dd/mm/aaaa" e escreva a data por extenso. Exemplo: Para a entrada "22/04/2010" deve ser escrito “22 de abril de 2010.
2. Imprima a data formatada no arquivo `index.html`
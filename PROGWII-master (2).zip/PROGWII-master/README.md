# PROGWII
Lista de Exercícios Propostos para as Atividades de Ensino Remotas da Disciplina Programação Web II

###### Antes de começar
- Crie uma conta no GitHub
- Faça `Fork` desse projeto para a sua conta
- Resolva os Exercícios Propostos
- O prazo para entrega será divulgado pelo professor

```javascript
console.log('Bons Estudos!')
```
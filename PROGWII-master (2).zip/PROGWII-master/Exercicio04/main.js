function calcula() {
	var num1 = document.querySelector(".num1").value;
	var num2 = document.querySelector(".num2").value;
	var num3 = document.querySelector(".num2").value;
	var nome = document.querySelector(".nome").value;

	var media = (((parseInt(num1) + parseInt(num2) + parseInt(num3)))/3);

		if (media <= 4) {
			document.querySelector(".media").innerHTML = ((("A média final do aluno: \n" + nome + " \n do curso Integrado é: \n" + media + " \n Seu status é Reprovado: \n")));
		}
		if (media >= 7){
			document.querySelector(".media").innerHTML = ((("A média final do aluno: \n" + nome + " \n do curso Integrado é: \n" + media + " \n Seu status é Aprovado: \n")));
		}
		else{
			document.querySelector(".media").innerHTML = ("Em Exame, Media até o momento \n" + media);
		}

		
}

